//
//  CollectionViewCell.swift
//  MyCV
//
//  Created by Juan carlos De la parra on 8/2/19.
//  Copyright © 2019 What Banged. All rights reserved.
//

import UIKit

class SeriesCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var itemImage: UIImageView!
    @IBOutlet weak var itemLabel: UILabel!
}
