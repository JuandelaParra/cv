//
//  LostCollectionViewCell.swift
//  CollectionView_Intro
//
//  Created by Luis Rollon Gordo on 16/1/17.
//  Copyright © 2017 EfectoApple. All rights reserved.
//

import UIKit

class SeriesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var itemImage: UIImageView!
    @IBOutlet weak var itemLabel: UILabel!
    

}
