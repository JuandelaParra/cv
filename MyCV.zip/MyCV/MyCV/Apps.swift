//
//  Apps.swift
//  MyCV
//
//  Created by WhatBanged on 8/1/19.
//  Copyright © 2019 What Banged. All rights reserved.
//

import UIKit

class Apps: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var collectionView: UICollectionView!
    let AppsList = ["Synapsis", "Synecdoque", "Haiki", "Ku"]
    let PhotosList = ["synapsis.png", "synecdoque.png", "haiki.png", "ku.png"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return AppsList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let identifier = "Item"
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath) as! SeriesCollectionViewCell
        print (cell)
        print (indexPath)
        print (indexPath.row)
        cell.itemLabel.text = AppsList[indexPath.row]
        print(cell.itemLabel.text as Any)
        print(PhotosList[indexPath.row])
        let photo = UIImage(named:PhotosList[indexPath.row])
        cell.itemImage.image = photo
        
        return cell
    }
    
    
    
}
