//
//  InfoView.swift
//  MyCV
//
//  Created by Juan carlos De la parra on 8/2/19.
//  Copyright © 2019 What Banged. All rights reserved.
//

import UIKit

struct CV {
    var Titulo: String
    var Contenido: String
}



class InfoView: UIViewController, XMLParserDelegate {
    
    
    @IBOutlet weak var titulo: UILabel!
    @IBOutlet weak var contenido: UILabel!
    
    var Titulo = String()
    var Contenido = String()
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
    
        if let path = Bundle.main.url(forResource: "CV", withExtension: "xml") {
            if let parser = XMLParser(contentsOf: path) {
                parser.delegate = self
                parser.parse()
            }
        }
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        
        if elementName == "to" {
            Titulo = String()
            
        }
        if elementName == "body" {
            Contenido = String()
        }
        
        //self.elementName = elementName
    }
    
    // 2
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "to" {
             titulo.text = Titulo
        }
        if elementName == "body" {
            contenido.text = Contenido
        }
    }
    
    // 3
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        let data = string.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        
        if (!data.isEmpty) {
            Titulo += data
            Contenido += data
            
        }
    }
}
